from flask import Flask, render_template, request, redirect, session  # Import Flask to allow us to create our app
app = Flask(__name__)
app.secret_key = "At some point this will make sense. "    # My secret key is my secret in this course. I am trying my best. 


@app.route('/count')          # The "@" decorator associates this route with the function immediately following
def counter():
    if 'visits' not in session:
        session['visits'] = 1
    else:
        session['visits'] += 1

    return render_template("counterpage.html")


@app.route('/destroysession')
def destruction():
    session.clear()
    return redirect('/count')



if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)    # Run the app in debug mode.


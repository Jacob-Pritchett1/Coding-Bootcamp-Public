from flask import render_template,request,redirect  # Import Flask to allow us to create our app
from flask_app import app    # Create a new instance of the Flask class called "app"
from flask_app.models.user import User

@app.route('/')          # The "@" decorator associates this route with the function immediately following
def all_users():
    users = User.get_all()
    return render_template('read.html', all_users=users)


@app.route('/create')
def create_form():
    return render_template("create.html")

@app.route('/user/create', methods=["POST"])
def create_user():
    User.save(request.form)
    return redirect('/')